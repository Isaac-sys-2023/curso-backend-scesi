import mongoose from "mongoose";
const horarioSchema = new mongoose.Schema(
  {
    dia: {
      type: String,
      enum: [
        "Lunes",
        "Martes",
        "Miércoles",
        "Jueves",
        "Viernes",
        "Sábado",
        "Domingo",
      ],
      required: true,
    },
    horaInicio: String,
    horaFin: String,
    modalidad: {
      type: String,
      enum: ["virtual", "presencial", "híbrido"],
      default: "virtual",
    },
    curso: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Curso",
      required: true,
    },
  },
  { timestamps: true }
);
export default mongoose.model("Horario", horarioSchema);
