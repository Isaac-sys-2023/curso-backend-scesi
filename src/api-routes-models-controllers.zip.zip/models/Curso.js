import mongoose from "mongoose";
const cursoSchema = new mongoose.Schema(
  {
    titulo: { type: String, required: true },
    descripcion: String,
    fechaInicio: Date,
    fechaFin: Date,
    duracionEnSemanas: Number,
    precioGeneral: Number,
    precioUMSS: Number,
    status: {
      type: String,
      enum: ["Por Iniciar", "En Progreso", "Finalizado"],
      default: "Por Iniciar",
    },
    estaCancelado: { type: Boolean, default: false },
    imgCurso: String,
    aficheImg: String,
    techs: [{ type: mongoose.Schema.Types.ObjectId, ref: "Tech" }],
    tutores: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    estudiantes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  },
  { timestamps: true }
);
export default mongoose.model("Curso", cursoSchema);
