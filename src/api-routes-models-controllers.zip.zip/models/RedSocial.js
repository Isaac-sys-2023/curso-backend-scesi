import mongoose from "mongoose";

const redSocialSchema = new mongoose.Schema({
  nombre: { type: String, required: true, unique: true },
  img: { type: String, required: true }, // logo o ícono de la red
});

export default mongoose.model("RedSocial", redSocialSchema);