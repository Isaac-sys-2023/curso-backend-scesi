import mongoose from "mongoose";
const techSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, unique: true },
    imgUrl: String,
  },
  { timestamps: true }
);
export default mongoose.model("Tech", techSchema);
