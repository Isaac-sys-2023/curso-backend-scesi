import express from "express";
import auth from "../middleware/auth.js";
import roles from "../middleware/roles.js";
import {
  listHorarios,
  createHorario,
  updateHorario,
  deleteHorario,
} from "../controllers/horarioController.js";
const router = express.Router();
router.get("/:id/horarios", listHorarios);
router.post("/:id/horarios", auth, createHorario);
router.put("/:id/horarios/:idHorario", auth, updateHorario);
router.delete("/:id/horarios/:idHorario", auth, deleteHorario);
export default router;
