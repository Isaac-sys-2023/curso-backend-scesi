import express from "express";
import auth from "../middleware/auth.js";
import roles from "../middleware/roles.js";
import upload from "../middleware/uploadCloud.js";
import {
  listRedes,
  createRed,
  updateRed,
  deleteRed,
} from "../controllers/redSocialController.js";

const router = express.Router();

router.get("/", listRedes);

router.post("/", auth, roles(["admin"]), upload.single("img"), createRed);
router.put("/:id", auth, roles(["admin"]), upload.single("img"), updateRed);
router.delete("/:id", auth, roles(["admin"]), deleteRed);

export default router;
