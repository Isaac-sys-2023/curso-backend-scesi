import express from "express";
import auth from "../middleware/auth.js";
import roles from "../middleware/roles.js";
import {
  listCursos,
  getCurso,
  createCurso,
  updateCurso,
  deleteCurso,
  addEstudiante,
  removeEstudiante,
} from "../controllers/cursoController.js";
import upload from "../middleware/uploadCloud.js";

const router = express.Router();

// público total
router.get("/", listCursos);
router.get("/:id", getCurso); // ahora es público

// acciones protegidas
// router.post("/", auth, roles(["admin"]), createCurso);
// router.put("/:id", auth, updateCurso);
router.post(
  "/",
  auth,
  roles(["admin"]),
  upload.fields([{ name: "imgCurso" }, { name: "aficheImg" }]),
  createCurso
);
router.put(
  "/:id",
  auth,
  upload.fields([{ name: "imgCurso" }, { name: "aficheImg" }]),
  updateCurso
);
router.delete("/:id", auth, roles(["admin"]), deleteCurso);

router.post("/:id/estudiantes", auth, addEstudiante);
router.delete("/:id/estudiantes/:userId", auth, removeEstudiante);

export default router;
