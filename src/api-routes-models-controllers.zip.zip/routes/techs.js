import express from "express";
import auth from "../middleware/auth.js";
import roles from "../middleware/roles.js";
import upload from "../middleware/uploadCloud.js";
import {
  listTechs,
  createTech,
  updateTech,
  deleteTech,
} from "../controllers/techController.js";

const router = express.Router();

router.get("/", listTechs);

//router.post("/", auth, createTech);
//router.delete("/:id", auth, deleteTech);
// router.post('/', auth, roles(['admin']), createTech);
// router.delete('/:id', auth, roles(['admin']), deleteTech);
router.post("/", auth, roles(["admin"]), upload.single("imgUrl"), createTech);
router.put("/:id", auth, roles(["admin"]), upload.single("imgUrl"), updateTech);
router.delete("/:id", auth, roles(["admin"]), deleteTech);

export default router;
