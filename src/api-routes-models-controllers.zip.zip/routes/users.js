import express from "express";
import auth from "../middleware/auth.js";
import roles from "../middleware/roles.js";
import upload from "../middleware/uploadCloud.js";
import {
  listUsers,
  getUser,
  updateUser,
  deleteUser,
} from "../controllers/userController.js";
const router = express.Router();
router.get("/", auth, roles(["admin"]), listUsers);
router.get("/:id", auth, getUser);
// router.put("/:id", auth, updateUser);
router.put("/:id", auth, upload.single("imagen"), updateUser);
router.delete("/:id", auth, roles(["admin"]), deleteUser);
export default router;
