import Tech from "../models/Tech.js";
import cloudinary from "../config/cloudinary.js";

async function deleteCloudImage(url) {
  if (!url) return;
  const parts = url.split("/");
  const publicId = parts.slice(-2).join("/").split(".")[0];
  await cloudinary.uploader.destroy(publicId);
}

export const listTechs = async (req, res) => {
  const t = await Tech.find();
  res.json(t);
};

// export const createTech = async (req, res) => {
//   if (req.user.rol !== "admin")
//     return res.status(403).json({ msg: "Solo admin" });
//   const tech = new Tech(req.body);
//   await tech.save();
//   res.status(201).json(tech);
// };

// export const deleteTech = async (req, res) => {
//   if (req.user.rol !== "admin")
//     return res.status(403).json({ msg: "Solo admin" });
//   await Tech.findByIdAndDelete(req.params.id);
//   res.json({ msg: "Eliminado" });
// };
export const createTech = async (req, res) => {
  if (req.user.rol !== "admin")
    return res.status(403).json({ msg: "Solo admin" });

  const imgUrl = req.file?.path;
  if (!imgUrl) return res.status(400).json({ msg: "Imagen requerida" });

  const tech = new Tech({ nombre: req.body.nombre, imgUrl });
  await tech.save();
  res.status(201).json(tech);
};

export const updateTech = async (req, res) => {
  if (req.user.rol !== "admin")
    return res.status(403).json({ msg: "Solo admin" });

  const tech = await Tech.findById(req.params.id);
  if (!tech) return res.status(404).json({ msg: "No encontrado" });

  if (req.file) {
    await deleteCloudImage(tech.imgUrl);
    tech.imgUrl = req.file.path;
  }
  if (req.body.nombre) tech.nombre = req.body.nombre;

  await tech.save();
  res.json(tech);
};

export const deleteTech = async (req, res) => {
  if (req.user.rol !== "admin")
    return res.status(403).json({ msg: "Solo admin" });
  const tech = await Tech.findById(req.params.id);
  if (!tech) return res.status(404).json({ msg: "No encontrado" });
  await deleteCloudImage(tech.imgUrl);
  await tech.deleteOne();
  res.json({ msg: "Tech e imagen eliminadas" });
};
