import User from "../models/User.js";
import Curso from "../models/Curso.js";
import cloudinary from "../config/cloudinary.js";

export const listUsers = async (req, res) => {
  const users = await User.find().select("-password");
  res.json(users);
};

// export const getUser = async (req, res) => {
//   const { id } = req.params;
//   const user = await User.findById(id).select("-password");
//   if (!user) return res.status(404).json({ msg: "No encontrado" });
//   // tutors can only fetch themselves or users they manage? keep simple: admin or self
//   if (req.user.rol !== "admin" && req.user._id.toString() !== id)
//     return res.status(403).json({ msg: "Acceso denegado" });
//   res.json(user);
// };
export const getUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findById(id).select("-password");
  if (!user) return res.status(404).json({ msg: "No encontrado" });

  const isSelf = req.user._id.toString() === id;
  const isAdmin = req.user.rol === "admin";
  let isTutorDeEsteUsuario = false;

  // si es tutor, verificamos si el usuario está en sus cursos
  if (req.user.rol === "tutor") {
    const cursos = await Curso.find({ tutores: req.user._id, estudiantes: id });
    if (cursos.length > 0) isTutorDeEsteUsuario = true;
  }

  if (!(isSelf || isAdmin || isTutorDeEsteUsuario)) {
    return res.status(403).json({ msg: "Acceso denegado" });
  }

  res.json(user);
};

// export const updateUser = async (req, res) => {
//   const { id } = req.params;
//   // password cannot be updated here
//   if (req.body.password) delete req.body.password;
//   // only admin or the user themself
//   if (req.user.rol !== "admin" && req.user._id.toString() !== id)
//     return res.status(403).json({ msg: "Acceso denegado" });
//   const updated = await User.findByIdAndUpdate(id, req.body, {
//     new: true,
//   }).select("-password");
//   res.json(updated);
// };
export const updateUser = async (req, res) => {
  const { id } = req.params;
  if (req.body.password) delete req.body.password;
  if (req.user.rol !== "admin" && req.user._id.toString() !== id)
    return res.status(403).json({ msg: "Acceso denegado" });

  const user = await User.findById(id);
  if (!user) return res.status(404).json({ msg: "No encontrado" });

  // si hay nueva imagen subida
  if (req.file) {
    await deleteCloudImage(user.imagen); // borra la vieja
    req.body.imagen = req.file.path; // nueva URL Cloudinary
  }

  Object.assign(user, req.body);
  await user.save();
  res.json(user);
};

// export const deleteUser = async (req, res) => {
//   const { id } = req.params;
//   if (req.user.rol !== "admin")
//     return res.status(403).json({ msg: "Solo admin" });
//   await User.findByIdAndDelete(id);
//   res.json({ msg: "Eliminado" });
// };
export const deleteUser = async (req, res) => {
  const { id } = req.params;
  if (req.user.rol !== "admin")
    return res.status(403).json({ msg: "Solo admin" });
  const user = await User.findById(id);
  if (!user) return res.status(404).json({ msg: "No encontrado" });
  await deleteCloudImage(user.imagen);
  await user.deleteOne();
  res.json({ msg: "Usuario e imagen eliminados" });
};

async function deleteCloudImage(url) {
  if (!url) return;
  const parts = url.split("/");
  const publicId = parts.slice(-2).join("/").split(".")[0]; // carpeta/archivo sin extensión
  await cloudinary.uploader.destroy(publicId);
}
